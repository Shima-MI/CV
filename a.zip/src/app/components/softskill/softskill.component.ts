import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-softskill',
  templateUrl: './softskill.component.html',
  styleUrls: ['./softskill.component.css']
})
export class SoftskillComponent implements OnInit {
 @Input() softSkill:any;

  constructor() { }

  ngOnInit(): void {
  }

}
